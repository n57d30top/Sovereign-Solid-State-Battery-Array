﻿# Portable Six-Champion Battery Export

Date: 2026-03-23

This package contains the six requested battery champions as a portable research export:

1. Li6PS5Br
2. Li6PS5Cl0.25Br0.75
3. Li6PS5Cl0.8Br0.2
4. Li6.5La3Zr1.5Ta0.5O12
5. Li6.6La3Zr1.5Ta0.3Al0.2O12
6. Na3.05Zr1.95Mn0.05Si2P1O12

What is included:
- baseline crystal seeds per family
- champion structure seeds for each requested variant
- atomistic scene, run, thermo, and log artifacts that exist locally
- sanitized champion, batch, and feedback JSON with only package-relative file references
- a short per-variant summary and an export-summary.json for quick review

What is not included:
- no internal machine-local paths
- no repo-wide registry dumps
- no complete wet-lab manufacturing recipe

Manufacturing warning:
- This package is suitable for evaluation, screening review, and reproduction of the included digital artifacts.
- It is not sufficient on its own to manufacture the materials in a lab.
- Missing information includes precursor specifications, stoichiometric excess policy, milling route, calcination profile, sintering profile, pellet pressing, atmosphere control, electrode stack-up, and validation SOPs.
