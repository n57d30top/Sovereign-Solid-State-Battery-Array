﻿# Manufacturing Gaps

The repository snapshot used for this export does not provide a complete laboratory synthesis package.

Missing items before third-party fabrication:
- precursor suppliers, grades, and purity requirements
- exact weighing sheet and excess-lithium or excess-sodium policy
- milling and mixing method, media, solvent, and dwell times
- calcination temperatures, ramps, holds, and atmosphere
- sintering temperatures, ramps, holds, and atmosphere
- pellet geometry, pressing force, binder choice, and density target
- electrode pairing, separator, current collector, and cell assembly details
- XRD, EIS, DC polarization, cycling, and safety validation SOPs

Use this export as a candidate-evaluation packet, not as a production-ready recipe.
